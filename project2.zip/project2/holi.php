<html>
<title>WELCOME to FODDIE</title>
<head>
<link rel="stylesheet" type="text/css" href="c4.css">
</head>
<body>
<section>
<video src="smoke.mp4" autoplay muted></video>
<a href="login.html">
<h1>
<span>H</span>
<span>A</span>
<span>P</span>
<span>P</span>
<span>Y</span>   
<span>H</span>
<span>O</span>
<span>L</span>
<span>I</span>
</h1>
</a>
</section>
</body>
</html>