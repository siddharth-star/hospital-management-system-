
<html>
<title>WELCOME to FODDIE</title>
<head>
<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
<header>
</div>
<div class="title">
<h2>WELCOME</h2>

</div>

<div class="button">
<a href='first.php'>
<img src='f1.png' width='250px'>
<h3 align ='center' style="color:white; font-size:25px;">User</h3></a>
</div>
<div class="button2">
<a href='first1.php'>
<img src='f2.png' width='250px'>
<h3 align ='center' style="color:white; font-size:25px;">Admin</h3></a>
</div>

</header>

</body>
</html>