<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="softwarecss.css">
<title>Online Diagnosis</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div id="full">
	<div id="header">
        <div id="nav">
        	<ul>
        		<li><a class="active" href="#">Add Test Details</a></li>
        		<li><a href="#">Add Parameters</a></li>
        		<li><a href="#">View Patient Appoinment Details</a></li>
        		<li><a href="#">Patient Test Details</a></li>
        		<li><a href="#">Report</a></li>
        		<li><a href="#">Logout</a></li>
        	</ul>
        </div>
	</div>
</div>

<div class="content1">
	<div class="centerwr">
		<div class="para">
		<div class="para1">Online Diagnostic Lab Reporting System</div>
	    </div>
	</div>
</div>

<p class="texto">Add Test Details</p>
<div class="Registro">
<!--<form method="post" action="https://getform.org/f/70415a77-d632-4883-bf07-2e15d3f557da">-->

<!--<form action="/action_page.php" onsubmit="myFunction()">-->
<form action="insert1.php" method="post"></form>
<span class="fontawesome-user"></span><input type="text"  name="id" required placeholder="Enter Id" autocomplete="off"> 
<span class="fontawesome-envelope-alt"></span><input type="text" id="email" name="testtype" required placeholder="Test Type" autocomplete="off">
<span class="fontawesome-lock"></span><input type="text"  style="background-color: #fff;
	border-top: 2px solid #2c90c6;
	border-right: 1px solid #000;
	border-bottom: 2px solid #2c90c6;
	border-left: 1px solid #000;
	border-radius: 0 0 5px 5px;
	-moz-border-radius: 0 0 5px 5px;
	-webkit-border-radius: 0 0 5px 5px;
  -o-border-radius: 0 0 5px 5px;
  -ms-border-radius: 0 0 5px 5px;
	color: #363636;
	margin-bottom: 20px;
	padding-left: 36px;
	width: 204px;" name="cost" id="password" required placeholder="Cost" autocomplete="off"> 
			<input type="submit" value="Submit" title="Registra tu cuenta">
  </form>
  <script>
function myFunction() {
  alert("The form was submitted");
}
</script>

</body>
</html>

 