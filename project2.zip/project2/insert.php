<?php
$con=mysqli_connect('127.0.0.1','root','');
if (!$con) {
	echo "Not connected to server";
}
if(mysqli_select_db($con,'online diagnosis'))
{
	echo "Database not selected";
}
$ID=$_post['id'];
$TestType=$_post['testtype'];
$Cost=$_post['cost'];


$sql="INSERT INTO test_details(TestType,Cost) VALUES($TestType,$Cost)";

if(mysqli_query($con,$sql))
{
	echo "Not inserted";
}
else
{
	echo "Inserted";
}
header(refresh:2;url=testdetails.html);
?>