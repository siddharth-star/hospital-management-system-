<html>
<head>
<script type="text/javascript">
var n1=prompt("enter rows ");
var n2=prompt("enter column");
var i;
for(i=1;i<=n2;i++)
{

alert(i*n1);
}
ale
</script>
</head>
<body>
</body>
</html>