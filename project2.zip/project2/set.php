<html>
<body>
<script>prompt('ADDITION INFO')</script>
<script>confirm('you sure you wn to submit')</script>
<?php
$x=$_POST["yname"];
$y=$_POST["num"];
$z=$_POST["add"];
$a=$_POST["gender"];
$b=$_POST["hobby"];
echo "Your data is stored successfully \n";

?>
</body>
</html>