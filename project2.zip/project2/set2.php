<html>
<body>
<?php
$x=0;
$y=0;
$n=$_POST['yname'];
if($n%2==0)
$x=1;
$fact=1;
for($i=1;$i<=$n;$i++)
$fact=$fact*$i;
if($x==1)
{
echo"alert( "$n is even and facyorial is $fact ")";
}
else
{
echo"alert( "$n is odd and facyorial is $fact ")";
}
?>
</body>
<html>