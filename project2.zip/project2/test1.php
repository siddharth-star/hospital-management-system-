<html>
    <head>
        <title>Wellcome to Foodie | Store</title>
        <meta name="description" content="This is the description">
        <link rel="stylesheet" href="styles.css" />
        <script src="store.js" async></script>
    </head>
    <body>
        <header class="main-header">
            <nav class="main-nav nav">
                <ul>
<li><a href ="forth.php" class ="active">HOME</a></li>
<li><a href ="break.php">BREAKFAST</a></li>
<li><a href ="break.php">BEVAGERS</a></li>
<li><a href ="break.php">MEALS</a></li>
<li><a href ="break.php">DESERTS</a></li>
</ul>
            </nav>
            <h1 class="band-name band-name-large">Light Dine</h1>
        </header>

      

       <form method="post" name="myform" action="payment.php">  


        <section class="container content-section">
            <h2 class="section-header">MENU</h2>
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title">Coffee</span>
                    <img class="shop-item-image" src="t1.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">50 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Sweet</span>
                    <img class="shop-item-image" src="o9.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">80 &#8377;</span>
                        <button class="btn btn-primary shop-item-button"type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Honey tea</span>
                    <img class="shop-item-image" src="m4.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">90 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Pani puri</span>
                    <img class="shop-item-image" src="s5.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">50 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </section>
     




   <section class="container content-section">
            
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title">Dosa</span>
                    <img class="shop-item-image" src="s7.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">100 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Pizza</span>
                    <img class="shop-item-image" src="w3.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">120 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </section>






   <section class="container content-section">
           
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title">Friut</span>
                    <img class="shop-item-image" src="w2.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">40 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Juice</span>
                    <img class="shop-item-image" src="h2.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">30 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </section>











   <section class="container content-section">
            
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title">Bread</span>
                    <img class="shop-item-image" src="a5.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">20 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Thali</span>
                    <img class="shop-item-image" src="s6.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">150 &#8377;</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </section>






       

       
        <section class="container content-section">
            <h2 class="section-header">CART</h2>
            <div class="cart-row">
                <span class="cart-item cart-header cart-column">ITEM</span>
                <span class="cart-price cart-header cart-column">PRICE</span>
                <span class="cart-quantity cart-header cart-column">QUANTITY</span>
            </div>
            <div class="cart-items">
            </div>
            <div class="cart-total">
               
               
                <strong class="cart-total-title" name="total">Total</strong>
               
               
               
                <span class="cart-total-price">0 &#8377;</span>
            </div>
            <br><hr><br><div align="center" class="abc">
            <?php
            $total = "<script>document.wirte(total)</script>";


            ?>
           

            <input type ="hidden" name="total" value="<?php echo "$total";?>">
            <input type ="submit" value= "Want Eat"><br>
             <br><hr><br>
            </div>
           <br>
        </section>
        <br>
       </form>
       
      
