
<html>
<title>WELCOME to Health Care</title>
<head>
<link rel="stylesheet" type="text/css" href="s2.css">
</head>
<body>
<header>
<div class="main">
<div id ="d1" ><br>
<h1 align="center"><b>Healthy</b></h1>
</div>
<ul>
<li><a href='s2.php' class='btn'>HOME</a></li>
<li><a href='report.html' class='btn'>REPORT</a></li>
<li><a href='appoint.php' class='btn'>APPOINTMENT</a>
</li>
<li><a href='donation1.php' class='btn'>DONATION</a>
<li><a href='feeback1.php' class='btn'>FEEDBACK</a>
</ul>
</div>
<div class="title">
<h2>WELCOME</h2>
</div>

<div class="button">
<a href='health.php' class='btn'>Health</a>
<a href='track.php' class='btn'>Track</a>
</div>


</header>

</body>
</html>